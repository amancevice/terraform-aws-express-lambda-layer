0.1.7 / 2015-07-28
==================

  * Fixed regression with escaped round brackets and matching groups.

0.1.6 / 2015-06-19
==================

  * Replace `index` feature by outputting all parameters, unnamed and named.

0.1.5 / 2015-05-08
==================

  * Add an index property for position in match result.

0.1.4 / 2015-03-05
==================

  * Add license information

0.1.3 / 2014-07-06
==================

  * Better array support
  * Improved support for trailing slash in non-ending mode

0.1.0 / 2014-03-06
==================

  * add options.end

0.0.2 / 2013-02-10
==================

  * Update to match current express
  * add .license property to component.json
