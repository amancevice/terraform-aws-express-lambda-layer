<a name="3.3.5"></a>
## [3.3.5](https://github.com/awslabs/aws-serverless-express/compare/v3.3.4...v3.3.5) (2018-08-20)


### Bug Fixes

* apply Content-Length header when missing ([b0927b8](https://github.com/awslabs/aws-serverless-express/commit/b0927b8)), closes [#147](https://github.com/awslabs/aws-serverless-express/issues/147) [#106](https://github.com/awslabs/aws-serverless-express/issues/106) [#130](https://github.com/awslabs/aws-serverless-express/issues/130)
* apply Content-Length header when missing ([#175](https://github.com/awslabs/aws-serverless-express/issues/175)) ([c2f416b](https://github.com/awslabs/aws-serverless-express/commit/c2f416b))

<a name="3.3.4"></a>
## [3.3.4](https://github.com/awslabs/aws-serverless-express/compare/v3.3.3...v3.3.4) (2018-08-19)


### Bug Fixes

* update example to use 3.3.3 ([bc7bdaf](https://github.com/awslabs/aws-serverless-express/commit/bc7bdaf))

<a name="3.3.3"></a>
## [3.3.3](https://github.com/awslabs/aws-serverless-express/compare/v3.3.2...v3.3.3) (2018-08-16)


### Bug Fixes

* add src/ to package.json files ([a412ec7](https://github.com/awslabs/aws-serverless-express/commit/a412ec7))

<a name="3.3.0"></a>
# [3.3.0](https://github.com/awslabs/aws-serverless-express/compare/v3.2.0...v3.3.0) (2018-08-16)


### Features

* add option of specifying resolveMode ([#173](https://github.com/awslabs/aws-serverless-express/issues/173)) ([582b88d](https://github.com/awslabs/aws-serverless-express/commit/582b88d))
